import { Html } from '@react-three/drei'
import { useEffect, useRef } from 'react'
import type { ChangeEvent, Dispatch, SetStateAction } from 'react'

type IntroGateProps = {
  value: string
  setValue: Dispatch<SetStateAction<string>>
  target: string
}

const IntroGate = ({ value, setValue, target }: IntroGateProps) => {
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    inputRef.current?.focus()
  }, [])

  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    setValue(event.target.value)
  }

  return (
    <Html center>
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '1rem',
          padding: '2rem',
          background: 'rgba(10, 10, 12, 0.8)',
          borderRadius: '0.75rem',
          boxShadow: '0 0 48px rgba(0, 0, 0, 0.65)',
        }}
      >
        <p
          style={{
            margin: 0,
            fontSize: '1.5rem',
            fontWeight: 500,
            letterSpacing: '0.04em',
          }}
        >
          Not all magic protects.
        </p>
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={handleChange}
          placeholder={target}
          style={{
            padding: '0.75rem 1.25rem',
            minWidth: '260px',
            borderRadius: '999px',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            background: 'rgba(20, 20, 24, 0.9)',
            color: '#f6f6f6',
            textAlign: 'center',
            fontSize: '1rem',
            outline: 'none',
          }}
        />
      </div>
    </Html>
  )
}

export default IntroGate
