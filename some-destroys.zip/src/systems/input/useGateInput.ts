import { useState } from 'react'

const TARGET = 'some destroys'

const useGateInput = () => {
  const [value, setValue] = useState('')
  const unlocked = value.trim().toLowerCase() === TARGET

  return {
    value,
    setValue,
    unlocked,
    target: TARGET,
  }
}

export default useGateInput
