import Experience from '../experience/Experience.tsx'

const App = () => {
  return <Experience />
}

export default App
